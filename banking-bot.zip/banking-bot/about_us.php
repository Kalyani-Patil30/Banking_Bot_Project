<?php
    include "header.php";
    include "navbar.php";
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="about_us.css">
</head>

<body>
<div class="flex-container" style="border-bottom: 0;
                                           border-top-left-radius: 10px;
                                           border-top-right-radius: 10px;">

            <div class="flex-item">
                <h1 id="sub-contact">About Group Members</h1>
                <p id="sub-contact">
                Akanksha Jadhav<br>
                Gokul Patil<br>
                Aditya sulokar<br>
                Rohan Patil<br>
                </p>
            </div>
</div>

 <div class="flex-container" style="border-top: 0;
                                           border-bottom-left-radius: 10px;
                                           border-bottom-right-radius: 10px;">
            















 <!-- <div class="flex-container-background">
        <div class="flex-container-heading">
            <h1 id="about">About Us</h1>
        </div>

        <div class="flex-container" style="border-bottom: 0;
                                           border-top-left-radius: 10px;
                                           border-top-right-radius: 10px;">
            <div class="flex-item"> 
                <h1 id="sub-contact">Corporate Headquarters</h1>
                <p id="sub-contact">
                    Corporate HQ<br>Bank Of DSP<br>
                    1985 Cedar Bridge Ave, Suite 3<br>
                    Lakewood, NY 08701
                </p>
            </div>
            <div class="flex-item">
                <h1 id="sub-contact">General Contact</h1>
                <p id="sub-contact">
                    Toll-Free: 888-968-6822<br>
                    Phone: 732-367-5505<br>
                    Fax: 732-367-2313<br>
                    Email: office@bankofdsp.com
                </p>
            </div>
        </div>

        <div class="flex-container" style="border-top: 0;
                                           border-bottom-left-radius: 10px;
                                           border-bottom-right-radius: 10px;">
            <div class="flex-item">
                <h1 id="sub-contact">Customer Care (24x7)</h1>
                <p id="sub-contact">
                    Toll-Free: 888-966-6992<br>
                    Phone: 732-666-5555<br>
                    Email: office@bankofdsp.com
                </p>
            </div>
            <div class="flex-item">
                <h1 id="sub-contact">Live Chat</h1>
                <p id="sub-contact">
                    Download our app and live chat<br>
                    with our customer care !<br>
                    App available on Google Play<br>
                    and iPhone-AppStore.
                </p>
            </div>
        </div>
    </div>
-->
</body>
</html>
